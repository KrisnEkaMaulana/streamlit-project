## Bike Rentals 
## Final Project Data Analytics

## This is a final project from Dicoding in the "Belajar Analisis Data Dengan Python" course to make analysis and create a dashboard from the bike sharing dataset. In the notebook file, I attached the way I did the analysis from : 

1. Data Wrangling,
2. Exploratory Data Analysis
3. Data Visualization.